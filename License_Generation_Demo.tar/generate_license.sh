#!/bin/bash

# Check if the correct number of arguments has been provided
#if [ "$#" -ne 3 ]; then
#   echo "Usage: ./generate_license.sh <system revision> <input file> <output file>"
#    exit 1
#fi

# Assign the arguments to variables
system_revision=$1
input_file=$2
output_file=$3
no_of_days=$4

# Call the Java program with the arguments
java -jar LicenseType.jar $system_revision $input_file $output_file $no_of_days

# Check if the Java program executed successfully
#if [ "$?" -eq 0 ]; then
#if [ -f "$output_file" ]; then
#    echo "License generated successfully."
#else
#    echo "An error occurred while generating the license."
#    exit 1
#fi
